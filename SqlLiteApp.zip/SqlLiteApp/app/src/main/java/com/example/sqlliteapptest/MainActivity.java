package com.example.sqlliteapptest;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    Button btn_find, btn_insert;
    EditText edtName, edtAge, edtCity, edtID;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtName  = findViewById(R.id.edt_Name);
        edtAge   = findViewById(R.id.edt_Age);
        edtCity  = findViewById(R.id.edt_City);
        edtID    = findViewById(R.id.edt_ID);


    }

    // to insert member information to the database
    public void insert(View view)
    {

        // 1 - get all inputs


        String name = edtName.getText().toString();
        String city = edtCity.getText().toString();
        int age = Integer.parseInt(edtAge.getText().toString());

        // 2 - Validate the input



        // 3 - Create the object


        // 4 - call the database helper class to insert into the database




    }

    // To find a member in the database
    public  void find(View view)
    {

        String id = edtID.getText().toString();


    }
}